
const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Body = Matter.Body;

var ball;

var post1;
var post2;
var ground;

function preload()
{
	
}

function setup() {
	createCanvas(800, 700);


	engine = Engine.create();
	world = engine.world;

	post1 = new Ground(700,650,10,20);
	post2 = new Ground(700,650,10,20);
	ground = new Ground(400,660,20,800);

	//crear los cuerpos aquí.
	var ball_options ={
		isStatic: false,
		restitution: 0.4,
		friction: 0,
		density: 1.2
	}

	ball = Bodies.circle(200,300,15,ball_options);
  	World.add(world,ball);

	Engine.run(engine);
	rectMode(CENTER);
  ellipseMode(RADIUS);
  
}


function draw() {
  rectMode(CENTER);
  background(0);

  post1.display();
  post2.display();
  ground.display();

  keyPressed();

  ellipse(ball.position.x,ball.position.y,15);
  Engine.update(engine);
  
  drawSprites();
 
}

function keyPressed() {
	if(keyCode === UP_ARROW){
		Matter.Body.applyForce(ball,{x: 0, y: 0},{x: 0.03, y: 0})
	}
}



